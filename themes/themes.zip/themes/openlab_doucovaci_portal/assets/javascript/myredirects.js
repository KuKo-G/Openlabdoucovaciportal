  function SigninRedirect() {
    window.location.href = "{{ 'signin'|page }}";
}

  function SignupRedirect() {
    window.location.href = "{{ 'signup'|page }}";
}