/*
 * Application
 */

$(document).tooltip({
    selector: "[data-toggle=tooltip]"
})
